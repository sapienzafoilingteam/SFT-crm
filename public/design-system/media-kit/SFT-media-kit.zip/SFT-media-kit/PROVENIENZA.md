# Provenienza delle risorse

Logo: ricostruzione vettoriale manuale del 22 ottobre 2026 a partire dal marchio SFT del sito. Vela, velista e monogramma sono stati ridisegnati con curve regolari; non si tratta del tracciato storico invariato. Il precedente SVG è conservato in docs/sft-logo-before.svg. Sei sagome chiuse e un cerchio, senza raster o font. La variante original usa il colore dominante storico #802431, burgundy il token SFT #822433, ink #1a1718 e white #ffffff. Master riproducibile: scripts/rebuild-logo.mjs. PNG trasparenti esportati a 2560 px di altezza.

Fotografie: copiate senza ritocchi dalla raccolta del sito del team. Non sono immagini generate. La raccolta non stabilisce i diritti di redistribuzione o l'autore di ogni scatto; conservare i crediti dove identificati.

Font: Geist e Geist Mono dal sito esistente; Kelson OTF dalla raccolta Identita_Visiva e WOFF dal sito. Non è stata trovata una licenza Kelson nella raccolta locale. L'inclusione preserva le risorse usate dal team, non concede nuovi diritti per la loro redistribuzione pubblica.

Pattern e template SVG: creati per questo sistema. Componenti UI: shadcn/ui (MIT), con personalizzazioni SFT; Radix e Lucide conservano le loro licenze.
